public class Reservation {
    int bookingId;
    String customerName;
    int roomNumber;
    boolean paymentDone;

    public Reservation(int bookingId, String customerName, int roomNumber) {
        this.bookingId = bookingId;
        this.customerName = customerName;
        this.roomNumber = roomNumber;
        this.paymentDone = true;
    }
}
