# Hotel-Reservation-System
Java console-based hotel reservation system
# Hotel Reservation System 🏨

A Java console-based application to manage hotel room bookings.

## Features
- View available rooms
- Book hotel rooms
- Cancel reservations
- Room categorization (Standard, Deluxe, Suite)
- Payment simulation
- Uses OOP concepts

## Technologies
- Java
- Console-based interface

## How to Run
javac *.java  
java HotelReservationSystem
