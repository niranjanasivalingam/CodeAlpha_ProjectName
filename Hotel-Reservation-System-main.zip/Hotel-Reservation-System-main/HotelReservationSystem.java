import java.util.ArrayList;
import java.util.Scanner;

public class HotelReservationSystem {

    static ArrayList<Room> rooms = new ArrayList<>();
    static ArrayList<Reservation> reservations = new ArrayList<>();
    static int bookingCounter = 1001;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        rooms.add(new Room(101, "Standard", 1500));
        rooms.add(new Room(102, "Standard", 1500));
        rooms.add(new Room(201, "Deluxe", 2500));
        rooms.add(new Room(202, "Deluxe", 2500));
        rooms.add(new Room(301, "Suite", 4000));

        while (true) {
            System.out.println("\n--- Hotel Reservation System ---");
            System.out.println("1. View Available Rooms");
            System.out.println("2. Book Room");
            System.out.println("3. Cancel Reservation");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    showAvailableRooms();
                    break;
                case 2:
                    bookRoom(sc);
                    break;
                case 3:
                    cancelReservation(sc);
                    break;
                case 4:
                    System.out.println("Thank you for using the system.");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    static void showAvailableRooms() {
        System.out.println("\nAvailable Rooms:");
        for (Room room : rooms) {
            if (room.isAvailable) {
                System.out.println("Room No: " + room.roomNumber +
                        " | Type: " + room.roomType +
                        " | Price: ₹" + room.price);
            }
        }
    }

    static void bookRoom(Scanner sc) {
        showAvailableRooms();
        System.out.print("Enter room number to book: ");
        int roomNo = sc.nextInt();
        sc.nextLine();

        for (Room room : rooms) {
            if (room.roomNumber == roomNo && room.isAvailable) {
                System.out.print("Enter customer name: ");
                String name = sc.nextLine();

                System.out.println("Processing payment of ₹" + room.price + "...");
                System.out.println("Payment successful!");

                room.isAvailable = false;
                Reservation res = new Reservation(bookingCounter++, name, roomNo);
                reservations.add(res);

                System.out.println("Booking successful!");
                System.out.println("Booking ID: " + res.bookingId);
                return;
            }
        }
        System.out.println("Room not available!");
    }

    static void cancelReservation(Scanner sc) {
        System.out.print("Enter booking ID to cancel: ");
        int id = sc.nextInt();

        for (Reservation res : reservations) {
            if (res.bookingId == id) {
                reservations.remove(res);

                for (Room room : rooms) {
                    if (room.roomNumber == res.roomNumber) {
                        room.isAvailable = true;
                        break;
                    }
                }
                System.out.println("Reservation cancelled successfully.");
                return;
            }
        }
        System.out.println("Invalid booking ID!");
    }
}
