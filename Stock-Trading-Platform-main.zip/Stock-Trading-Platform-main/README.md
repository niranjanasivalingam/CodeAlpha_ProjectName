# Stock-Trading-Platform
Java console-based stock trading platform
# Stock Trading Platform 📈

Java console-based application simulating a stock trading environment.

## Features
- Market data display
- Buy and sell stocks
- Portfolio tracking
- Transaction history
- OOP-based design

## Technologies
- Java
- Console-based interface
